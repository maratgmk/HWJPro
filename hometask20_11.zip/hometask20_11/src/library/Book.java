package library;

import java.time.LocalDate;

public class Book {
    private String name;
    private String author;
    private LocalDate edition;

    public Book() {

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Книга не может быть без названия");
        }
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        if ((author == null || author.isEmpty())) {
            throw new IllegalArgumentException("У книги должен быть автор");
        }
        this.author = author;
    }

    public LocalDate getEdition() {
        return edition;
    }

    public void setEdition(LocalDate edition) {
        if (edition == null) {
            throw new IllegalArgumentException("Год издания должен быть указан");
        }
        this.edition = edition;
    }

    public Book(LocalDate edition) {
        this.edition = edition;
    }

    public Book(String name, String author, LocalDate edition) {
        this(edition);
        this.name = name;
        this.author = author;
    }

    public void informEdition() {
        int rarity = LocalDate.now().getYear() - edition.getYear();
        if ((rarity > 50)) {
            System.out.println("Эта книга является раритетом");
        } else {
            System.out.println("Книга наш современник");
        }

    }

}




