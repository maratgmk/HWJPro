package library;

import java.time.LocalDate;

public class Reader {
    private String firstName;
    private String secondName;
    private LocalDate age;
    private String[] list;
    public Reader () {

    }
    public Reader(String firstName, String secondName) {
        this.firstName = firstName;
        this.secondName = secondName;
    }
    public Reader(LocalDate age) {
        this.age = age;
    }
    public Reader(String[] list) {
        this.list = list;
    }
    public Reader(String firstName, String secondName, LocalDate age, String[] list) {
        this(firstName, secondName);
        this.age = age;
        this.list = list;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        if ((firstName == null || firstName.isEmpty())) {
            throw new IllegalArgumentException("Имя не может быть пустым");
        }
        this.firstName = firstName;
    }
    public String getSecondName() {
        return secondName;
    }
    public void setSecondName(String secondName) {
        if (secondName == null || secondName.isEmpty()) {
            throw new IllegalArgumentException("Поле фамилия должно быть заполненным");
        }
        this.secondName = secondName;
    }
    public LocalDate getAge() {
        return age;
    }
    public void setAge(LocalDate age) {
        if (age == null) {
            throw new IllegalArgumentException("Должен быть указан возраст");
        }
        this.age = age;
    }
    public String[] getList() {
        return getList();
    }
    public void setList(String[] list) {
        if (list.length == 0) {
            throw new IllegalArgumentException("Карточка взятых книг должна быть оформлена");
        }
        this.list = list;
    }
    public void getBook() {
        System.out.println("Читатель взял книгу: ");
    }
    public void returnBook() {
        System.out.println("Читатель вернул книгу: ");
    }





}
