package library;

public class Librarian {
    private String name;
    private int experience;
    private String[] stuff;
    public Librarian() {

    }
    public Librarian(String name, int experience) {
        this.name = name;
        this.experience = experience;
    }
    public Librarian(String[] stuff) {
        this.stuff = stuff;
    }
    public String getName() {
        return getName();
    }
    public void setName(String name) {
        if(name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Имя должно быть названо");
        }
        this.name = name;
    }
    public int getExperience() {
        return experience;
    }
    public void setExperiance(int experiance) {
        if(experiance < 0) {
            throw new IllegalArgumentException("Трудовой стаж не может быть отрицательным");
        }
        this.experience = experiance;
    }
    public String[] getStuff(String[] stuff) {
        return stuff;
    }
    private void setStuff(String[] stuff) {
        if (stuff.length == 0) {
            throw new IllegalArgumentException("Библиотека не может быть пустой");
        }
        this.stuff = stuff;
    }
    public void giveBook(Book book) {
        System.out.println("Библиотекарь выдал книгу: " + book.getName());
    }
    public void takeBook(Book book) {
        System.out.println("Библиотекарь принял книгу: " + book.getName());
    }


}
