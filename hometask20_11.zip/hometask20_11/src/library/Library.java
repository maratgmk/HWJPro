package library;
/*Управление Библиотекой.
Классы:
Книга (Book)
Поля: название, автор, год издания.
Методы: вывод информации о книге, проверка на старинность (старше 50 лет).

Читатель (Reader)
Поля: имя, возраст, список взятых книг (массив).
Методы: взять книгу, вернуть книгу.

Библиотекарь (Librarian)
Поля: имя, стаж работы, список доступных книг (массив).
Методы: выдать книгу читателю, принять книгу от читателя.

Библиотека (Library)
Поля: название, адрес, список библиотекарей (массив).
Методы: добавить библиотекаря, найти библиотекаря по имени.
 */

public class Library {
    private String namen;
    private String address;
    private String[] employee;

    public Library() {

    }
    public Library(String namen, String address) {
        this.namen = namen;
        this.address = address;
    }
    public Library(String[] employee) {
        this.employee = employee;
    }
    public String getNamen() {
        return namen;
    }
    public String getAddress() {
        return address;
    }
    public void setNamen(String namen) {
        if(namen == null || namen.isEmpty()) {
            throw new IllegalArgumentException("Имя должно быть в списке");
        }
        this.namen = namen;
    }
      public void setAddress(String address) {
        if(address == null || address.isEmpty()) {
            throw new IllegalArgumentException("Адрес библиотеки должен быть указан");
        }
        this.address = address;
      }
      public String[] getEmployee() {
        return employee;
      }
      public void setEmployee(String[] employee) {
        if (employee.length == 0) {
            throw new IllegalArgumentException("Список работников не должен быть пустым");
        }
        this.employee = employee;
      }





}
