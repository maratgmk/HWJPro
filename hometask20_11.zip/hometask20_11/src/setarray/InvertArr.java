package setarray;
/*Инвертировать массив, то есть изменить порядок элементов в массиве на обратный.

Поиск третьего по величине числа в массиве
 */

import java.util.Arrays;

public class InvertArr {
    public static void main(String[] args) {
        int[] arr = {2,76,1,9,11,15,57,3,23};
        System.out.println(Arrays.toString(arr));
        System.out.println(Arrays.toString(invertAr(arr)));

        System.out.println(searchFirstMax(arr));
        System.out.println(searchSecondMax(arr));
        System.out.println(searchThirdMax(arr));


    }


    private static int[] invertAr(int[] arr){

        int temp;
        for (int i = 0; i < arr.length/2; i++) {
            temp = arr[i];
            arr[i] = arr[arr.length -1 -i];
            arr[arr.length -1 -i] = temp;
        }

        return arr;
    }

    private static int searchFirstMax(int[] arr) {
        int firstMax = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if(firstMax > arr[i]) continue;
            if (firstMax < arr[i]) {
                firstMax = arr[i];
            }
        }
        return firstMax;
    }
    private static int searchSecondMax(int[] arr) {
        int secondMax = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (secondMax > arr[i]) continue;
            if ((secondMax < arr[i]) && arr[i] != searchFirstMax(arr)) {
                secondMax = arr [i];
            }
        }
        return secondMax;
    }
    private static int searchThirdMax(int[] arr) {
        int thirdMax = arr[0];
        for (int i = 0; i < arr[i]; i++) {
            if(thirdMax > arr[i]) continue;
            if (thirdMax < arr[i] && arr[i] != searchFirstMax(arr) && arr[i] != searchSecondMax(arr)) {
                thirdMax = arr[i];
            }
        }
        return thirdMax;
    }
}
