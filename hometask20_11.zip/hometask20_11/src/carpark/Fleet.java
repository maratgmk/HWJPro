package carpark;
/*
Транспортный Парк (Fleet)
Поля: название, адрес, список менеджеров парка (массив).
Методы: добавить менеджера, поиск менеджера по имени.
 */
public class Fleet {
    public String nomen;
    public String address;
    public String[] managers;

    public Fleet(String nomen, String address, String[] managers) {
        this.nomen = nomen;
        this.address = address;
        this.managers = managers;
    }

    public String findManager(){
       // FleetManager manager = new FleetManager();
        for (int i = 0; i < managers.length; i++) {

           // if (manager == managers[i])

        }
        return null;

    }
}
