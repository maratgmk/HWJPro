package carpark;

import carpark.Car;
import carpark.Driver;

import java.time.LocalDate;

public class MainFleet {
    Car car1 = new Car("BMW", "Wagon", LocalDate.of(2008, 3, 24));
    Driver driver = new Driver("John", 18);


}
