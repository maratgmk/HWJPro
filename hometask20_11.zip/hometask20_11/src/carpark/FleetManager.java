package carpark;
/*
Менеджер Парка (FleetManager)
Поля: имя, список автомобилей (массив), список водителей (массив).
Методы: добавить автомобиль в парк, назначить автомобиль водителю.
 */
public class FleetManager {
    public String name;
    public String[] autos;
    public String[] drives;

    public FleetManager(String name, String[] autos, String[] drives) {
        this.name = name;
        this.autos = autos;
        this.drives = drives;
    }


}
