package carpark;

import java.time.LocalDate;
/*Система Управления Транспортным Парком
Классы:Автомобиль (Car)
Поля: марка, модель, год выпуска.
Методы: вывод информации об автомобиле, проверка на техосмотр.
 */
public class Car {
    public String brand;
    public String model;
    public LocalDate date;

    public Car(){

    }

    public Car(String brand, String model, LocalDate date) {
        this.brand = brand;
        this.model = model;
        this.date = date;
    }



    public static void nameCar(String brand, String model, LocalDate date) {
        System.out.printf("Марка авто %s\n модель авто %s\n год выпуска %d\n ", brand, model, date.getYear());
    }
    public static void checkYear(LocalDate date){
        if((LocalDate.now().getYear() - date.getYear()) >= 2)
            System.out.println("Необходимо пройти техосмотр");
    }
}
