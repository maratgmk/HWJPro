package carpark;

import java.time.LocalDate;

/*
Водитель (Driver)
Поля: имя, стаж вождения, текущий автомобиль (Car).
Методы: назначить автомобиль, освободить автомобиль.
 */
public class Driver {
    public String name;
    public int experiance;
    public Car car;

    public Driver(String name, int experiance) {
        this.name = name;
        this.experiance = experiance;
    }
    public void takeCar(){
        Car car2 = new Car("MAZ", "F56best", LocalDate.of( 2021,3,16));
        System.out.println("Назначить авто: " + car2);
    }
    public  void outCar(){
        Car car = new Car();
        System.out.println("Освободить это авто: " + car);
    }
}
