import library.Book;
import library.Reader;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        Book book = new Book();
        book.setName("X718W");
        book.setAuthor("Clark");
        book.setEdition(LocalDate.of(1876,2,25));
        System.out.println(book.getName());
        System.out.println(book.getEdition());
        System.out.println(book.getAuthor());
        Book book1 = new Book("Assa","Stendal", LocalDate.of(1975,3,30));
        System.out.println(book1.getEdition());
        book.informEdition();
        book1.informEdition();

        Reader reader1 = new Reader("Bob", "Green", LocalDate.of(1927, 2 , 23), new String[]{"Assa", "Ugo"});
        reader1.getBook();
        reader1.setList(new String[] {"Assa", "Hugo", "Lego", "Rex"});
        reader1.returnBook();



    }
}