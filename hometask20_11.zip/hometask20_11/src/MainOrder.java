import productdelivery.Product;

public class MainOrder {
    public static void main(String[] args) {
        Product product1 = new Product("Butter", 12.8, 4.5);
        product1.checkProduct(product1);
        System.out.println("Привезите " + product1.loadProduct(product1) + " kg");
    }
}
