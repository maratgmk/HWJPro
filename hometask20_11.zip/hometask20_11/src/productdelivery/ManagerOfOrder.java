package productdelivery;

import java.util.Arrays;

public class ManagerOfOrder {
    public String[] orders;
    public String[] productNames;

    public ManagerOfOrder(String[] orders, String[] productNames) {
        this.orders = orders;
        this.productNames = productNames;
    }

    public String[] getOrders() {
        return orders;
    }

    public String[] getProductNames() {
        return productNames;
    }

    public void createNewOrder(String[] orders, String[] productNames){
        for (int i = 0; i < orders.length; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < productNames.length; j++) {
                sb.append(productNames[j]);

            }
            orders[i] = Arrays.toString(sb.toString().toCharArray());


        }



    }
    public StatusOrder changeStatus(StatusOrder statusOrder){
        return statusOrder;
    }




}
