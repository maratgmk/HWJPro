package productdelivery;

public enum StatusOrder {
    CANCELLED,
    DELIVERED,
    COMPOSED,
    PAYED

}
