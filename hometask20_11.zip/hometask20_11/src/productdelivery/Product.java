package productdelivery;

/*Система Управления Заказами
Классы: Товар (Product)
Поля: название, цена, количество на складе.
Методы: проверка наличия, обновление количества на складе.

Заказ (Order)
Поля: список товаров (массив), статус заказа, общая сумма.
Методы: добавить товар в заказ, рассчитать общую сумму.

Клиент (Customer)
Поля: имя, email, история заказов (массив).
Методы: сделать заказ, отменить заказ.

Менеджер Заказов (OrderManager)
Поля: список доступных товаров (массив), список заказов (массив).
Методы: обработка нового заказа, обновление статуса заказа. */
public class Product {
    public String name;
    public double price;
    public double quantity;

    public Product(String name, double price, double quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getQuantity() {
        return quantity;
    }

    public void checkProduct(Product product) {
        if (product.quantity == 0) {
            System.out.println("Пополните склад " + product.name);
        } else System.out.println("Продукта достаточно");
    }

    public double loadProduct(Product product) {
        if (product.quantity <= 5)
            product.quantity = 83;
        return product.quantity;
    }


}
