package productdelivery;

import java.util.Arrays;

public class OrderProduct {
    public String[] names;
    public StatusOrder status;
    public double sum;

    public OrderProduct(String[] names, StatusOrder status, double sum) {
        this.names = names;
        this.status = status;
        this.sum = sum;
    }

    public String[] getNames() {
        return names;
    }

    public StatusOrder getStatus() {
        return status;
    }

    public double getSum() {
        return sum;
    }

    public static double makeSum(Product product, double sum){
        sum = product.getQuantity() * product.getPrice();
        return sum;
    }
    public  void addOrder(String[] names, Product product){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.length; i++) {
            names[i] = product.getName();
            sb.append(names[i]);
        }
        System.out.println(Arrays.toString(sb.toString().toCharArray()));
    }


}
