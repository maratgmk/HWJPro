package productdelivery;

import java.util.Arrays;

public class CustomerOrder {
    public String name;
    public String email;
    public String[] history;

    public CustomerOrder(String name, String email, String[] history) {
        this.name = name;
        this.email = email;
        this.history = history;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String[] getHistory() {
        return history;
    }

    public void makeOrder(String[] history, Product product) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < history.length; i++) {
            history[i] = product.getName();
            sb.append(history[i]);
        }
        System.out.println(Arrays.toString(sb.toString().toCharArray()));
    }

    public void cancelOrder(String[] history, Product product) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < history.length; i++) {
            history[i] = product.getName();
            sb.append(history[i]);
        }
        System.out.println(Arrays.toString(sb.toString().toCharArray()));
    }

}
